import { DashboardHeader } from '@/components/dashboard/dashboard-header'
import { StatsCards } from '@/components/dashboard/stats-cards'
import { StoreLayoutGrid } from '@/components/dashboard/store-layout-grid'
import { TrafficHeatmap } from '@/components/dashboard/traffic-heatmap'
import { CustomerMovement } from '@/components/dashboard/customer-movement'
import { AIRecommendations } from '@/components/dashboard/ai-recommendations'
import { TrafficChart } from '@/components/dashboard/traffic-chart'

export default function DashboardPage() {
  return (
    <div className="min-h-screen bg-background">
      <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
        <DashboardHeader />
        
        <div className="mt-6">
          <StatsCards />
        </div>

        <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-3">
          {/* Left Column - Main Visualizations */}
          <div className="space-y-6 lg:col-span-2">
            <TrafficChart />
            
            <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
              <StoreLayoutGrid />
              <TrafficHeatmap />
            </div>

            <CustomerMovement />
          </div>

          {/* Right Column - AI Recommendations */}
          <div className="lg:col-span-1">
            <AIRecommendations />
          </div>
        </div>
      </div>
    </div>
  )
}
