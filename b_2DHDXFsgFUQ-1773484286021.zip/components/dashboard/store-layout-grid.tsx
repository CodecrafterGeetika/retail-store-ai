'use client'

import { useState, useCallback } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { cn } from '@/lib/utils'
import { GripVertical, Package, ShoppingCart, DoorOpen, Shirt, Sparkles, Coffee } from 'lucide-react'

interface StoreSection {
  id: string
  name: string
  icon: React.ReactNode
  color: string
  row: number
  col: number
  traffic: 'high' | 'medium' | 'low'
}

const initialSections: StoreSection[] = [
  { id: '1', name: 'Entrance', icon: <DoorOpen className="h-4 w-4" />, color: '#7c6aef', row: 0, col: 0, traffic: 'high' },
  { id: '2', name: 'Apparel', icon: <Shirt className="h-4 w-4" />, color: '#4ecdc4', row: 0, col: 1, traffic: 'medium' },
  { id: '3', name: 'Beauty', icon: <Sparkles className="h-4 w-4" />, color: '#ff6b6b', row: 0, col: 2, traffic: 'high' },
  { id: '4', name: 'Electronics', icon: <Package className="h-4 w-4" />, color: '#f7b731', row: 1, col: 0, traffic: 'medium' },
  { id: '5', name: 'Checkout', icon: <ShoppingCart className="h-4 w-4" />, color: '#45b7d1', row: 1, col: 1, traffic: 'high' },
  { id: '6', name: 'Cafe', icon: <Coffee className="h-4 w-4" />, color: '#96ceb4', row: 1, col: 2, traffic: 'low' },
]

export function StoreLayoutGrid() {
  const [sections, setSections] = useState<StoreSection[]>(initialSections)
  const [draggedSection, setDraggedSection] = useState<StoreSection | null>(null)
  const [dropTarget, setDropTarget] = useState<{ row: number; col: number } | null>(null)

  const handleDragStart = useCallback((section: StoreSection) => {
    setDraggedSection(section)
  }, [])

  const handleDragOver = useCallback((e: React.DragEvent, row: number, col: number) => {
    e.preventDefault()
    setDropTarget({ row, col })
  }, [])

  const handleDrop = useCallback((e: React.DragEvent, targetRow: number, targetCol: number) => {
    e.preventDefault()
    if (!draggedSection) return

    setSections(prev => {
      const newSections = [...prev]
      const targetSection = newSections.find(s => s.row === targetRow && s.col === targetCol)
      const draggedIndex = newSections.findIndex(s => s.id === draggedSection.id)

      if (targetSection) {
        const targetIndex = newSections.findIndex(s => s.id === targetSection.id)
        newSections[targetIndex] = { ...targetSection, row: draggedSection.row, col: draggedSection.col }
      }
      
      newSections[draggedIndex] = { ...draggedSection, row: targetRow, col: targetCol }
      return newSections
    })

    setDraggedSection(null)
    setDropTarget(null)
  }, [draggedSection])

  const handleDragEnd = useCallback(() => {
    setDraggedSection(null)
    setDropTarget(null)
  }, [])

  const getTrafficColor = (traffic: 'high' | 'medium' | 'low') => {
    switch (traffic) {
      case 'high': return 'bg-green-500'
      case 'medium': return 'bg-yellow-500'
      case 'low': return 'bg-red-500'
    }
  }

  const renderCell = (row: number, col: number) => {
    const section = sections.find(s => s.row === row && s.col === col)
    const isDropTarget = dropTarget?.row === row && dropTarget?.col === col
    const isDragging = draggedSection?.row === row && draggedSection?.col === col

    return (
      <div
        key={`${row}-${col}`}
        className={cn(
          'relative h-28 rounded-lg border-2 border-dashed transition-all duration-200',
          isDropTarget ? 'border-primary bg-primary/10' : 'border-border',
          isDragging && 'opacity-50'
        )}
        onDragOver={(e) => handleDragOver(e, row, col)}
        onDrop={(e) => handleDrop(e, row, col)}
      >
        {section && (
          <div
            draggable
            onDragStart={() => handleDragStart(section)}
            onDragEnd={handleDragEnd}
            className={cn(
              'absolute inset-1 flex cursor-grab flex-col items-center justify-center gap-1.5 rounded-md p-2 transition-all hover:scale-[1.02] active:cursor-grabbing',
              'bg-secondary/50 border border-border'
            )}
            style={{ borderLeftColor: section.color, borderLeftWidth: 3 }}
          >
            <div className="absolute right-1 top-1 text-muted-foreground">
              <GripVertical className="h-3 w-3" />
            </div>
            <div className="flex items-center gap-1.5">
              <span style={{ color: section.color }}>{section.icon}</span>
              <span className="text-xs font-medium text-foreground">{section.name}</span>
            </div>
            <div className="flex items-center gap-1">
              <span className={cn('h-1.5 w-1.5 rounded-full', getTrafficColor(section.traffic))} />
              <span className="text-[10px] text-muted-foreground capitalize">{section.traffic} traffic</span>
            </div>
          </div>
        )}
      </div>
    )
  }

  return (
    <Card className="border-border bg-card">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-base font-medium">Store Layout</CardTitle>
        <Badge variant="outline" className="text-xs font-normal">
          Drag to rearrange
        </Badge>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-3 gap-2">
          {[0, 1].map(row =>
            [0, 1, 2].map(col => renderCell(row, col))
          )}
        </div>
        <div className="mt-4 flex items-center justify-center gap-4 text-xs text-muted-foreground">
          <div className="flex items-center gap-1.5">
            <span className="h-2 w-2 rounded-full bg-green-500" />
            <span>High Traffic</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="h-2 w-2 rounded-full bg-yellow-500" />
            <span>Medium</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="h-2 w-2 rounded-full bg-red-500" />
            <span>Low</span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
