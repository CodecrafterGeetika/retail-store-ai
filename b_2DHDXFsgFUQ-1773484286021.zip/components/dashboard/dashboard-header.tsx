'use client'

import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { CalendarDays, Download, RefreshCw, Store } from 'lucide-react'
import { useState } from 'react'

export function DashboardHeader() {
  const [store, setStore] = useState('downtown')
  const [isRefreshing, setIsRefreshing] = useState(false)

  const handleRefresh = () => {
    setIsRefreshing(true)
    setTimeout(() => setIsRefreshing(false), 1000)
  }

  return (
    <header className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
      <div className="flex items-center gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary">
          <Store className="h-5 w-5 text-primary-foreground" />
        </div>
        <div>
          <h1 className="text-xl font-semibold text-foreground">Retail Analytics</h1>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="text-xs font-normal gap-1 text-muted-foreground">
              <span className="h-1.5 w-1.5 rounded-full bg-green-500 animate-pulse" />
              Live
            </Badge>
            <span className="text-xs text-muted-foreground">Last updated: Just now</span>
          </div>
        </div>
      </div>
      
      <div className="flex flex-wrap items-center gap-2">
        <Select value={store} onValueChange={setStore}>
          <SelectTrigger className="w-40 h-9">
            <Store className="mr-2 h-4 w-4 text-muted-foreground" />
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="downtown">Downtown Store</SelectItem>
            <SelectItem value="mall">Mall Location</SelectItem>
            <SelectItem value="airport">Airport Terminal</SelectItem>
          </SelectContent>
        </Select>

        <Button variant="outline" size="sm" className="h-9 gap-2">
          <CalendarDays className="h-4 w-4" />
          Today
        </Button>

        <Button 
          variant="outline" 
          size="icon" 
          className="h-9 w-9"
          onClick={handleRefresh}
        >
          <RefreshCw className={`h-4 w-4 ${isRefreshing ? 'animate-spin' : ''}`} />
        </Button>

        <Button variant="outline" size="sm" className="h-9 gap-2">
          <Download className="h-4 w-4" />
          Export
        </Button>
      </div>
    </header>
  )
}
