'use client'

import { useEffect, useState, useRef } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Play, Pause, RotateCcw } from 'lucide-react'

interface Customer {
  id: number
  x: number
  y: number
  targetX: number
  targetY: number
  color: string
}

const zones = [
  { id: 'entrance', name: 'Entrance', x: 10, y: 80, width: 80, height: 15 },
  { id: 'apparel', name: 'Apparel', x: 10, y: 10, width: 35, height: 30 },
  { id: 'electronics', name: 'Electronics', x: 55, y: 10, width: 35, height: 30 },
  { id: 'checkout', name: 'Checkout', x: 10, y: 45, width: 35, height: 30 },
  { id: 'beauty', name: 'Beauty', x: 55, y: 45, width: 35, height: 30 },
]

const colors = ['#7c6aef', '#4ecdc4', '#ff6b6b', '#f7b731', '#45b7d1']

const generateCustomers = (count: number): Customer[] => {
  return Array.from({ length: count }, (_, i) => {
    const zone = zones[Math.floor(Math.random() * zones.length)]
    return {
      id: i,
      x: zone.x + Math.random() * zone.width,
      y: zone.y + Math.random() * zone.height,
      targetX: zone.x + Math.random() * zone.width,
      targetY: zone.y + Math.random() * zone.height,
      color: colors[Math.floor(Math.random() * colors.length)]
    }
  })
}

export function CustomerMovement() {
  const [customers, setCustomers] = useState<Customer[]>([])
  const [isPlaying, setIsPlaying] = useState(true)
  const [activeCustomers, setActiveCustomers] = useState(24)
  const animationRef = useRef<number>()

  useEffect(() => {
    setCustomers(generateCustomers(24))
  }, [])

  useEffect(() => {
    if (!isPlaying) {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current)
      }
      return
    }

    const animate = () => {
      setCustomers(prev => prev.map(customer => {
        const dx = customer.targetX - customer.x
        const dy = customer.targetY - customer.y
        const distance = Math.sqrt(dx * dx + dy * dy)

        if (distance < 1) {
          const newZone = zones[Math.floor(Math.random() * zones.length)]
          return {
            ...customer,
            targetX: newZone.x + Math.random() * newZone.width,
            targetY: newZone.y + Math.random() * newZone.height
          }
        }

        return {
          ...customer,
          x: customer.x + dx * 0.02,
          y: customer.y + dy * 0.02
        }
      }))

      animationRef.current = requestAnimationFrame(animate)
    }

    animationRef.current = requestAnimationFrame(animate)
    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current)
      }
    }
  }, [isPlaying])

  const handleReset = () => {
    setCustomers(generateCustomers(24))
  }

  const getZoneCustomerCount = (zoneId: string) => {
    const zone = zones.find(z => z.id === zoneId)
    if (!zone) return 0
    return customers.filter(c => 
      c.x >= zone.x && c.x <= zone.x + zone.width &&
      c.y >= zone.y && c.y <= zone.y + zone.height
    ).length
  }

  useEffect(() => {
    setActiveCustomers(customers.length)
  }, [customers.length])

  return (
    <Card className="border-border bg-card">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <div>
          <CardTitle className="text-base font-medium">Customer Movement</CardTitle>
          <CardDescription className="text-muted-foreground">
            Live tracking simulation
          </CardDescription>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="secondary" className="text-xs">
            {activeCustomers} active
          </Badge>
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            onClick={() => setIsPlaying(!isPlaying)}
          >
            {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            onClick={handleReset}
          >
            <RotateCcw className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="relative aspect-[4/3] w-full rounded-lg border border-border bg-secondary/30 overflow-hidden">
          {/* Store zones */}
          {zones.map(zone => (
            <div
              key={zone.id}
              className="absolute rounded border border-border/50 bg-secondary/50 flex flex-col items-center justify-center transition-colors"
              style={{
                left: `${zone.x}%`,
                top: `${zone.y}%`,
                width: `${zone.width}%`,
                height: `${zone.height}%`
              }}
            >
              <span className="text-[10px] font-medium text-foreground/80">{zone.name}</span>
              <span className="text-[9px] text-muted-foreground">{getZoneCustomerCount(zone.id)} visitors</span>
            </div>
          ))}

          {/* Customers */}
          {customers.map(customer => (
            <div
              key={customer.id}
              className="absolute h-2 w-2 rounded-full transition-all duration-75 shadow-sm"
              style={{
                left: `${customer.x}%`,
                top: `${customer.y}%`,
                backgroundColor: customer.color,
                boxShadow: `0 0 6px ${customer.color}40`
              }}
            />
          ))}
        </div>

        <div className="mt-3 grid grid-cols-5 gap-2">
          {zones.map(zone => (
            <div key={zone.id} className="text-center">
              <div className="text-sm font-semibold text-foreground">{getZoneCustomerCount(zone.id)}</div>
              <div className="text-[10px] text-muted-foreground truncate">{zone.name}</div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
