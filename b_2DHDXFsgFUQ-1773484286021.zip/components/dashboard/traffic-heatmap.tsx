'use client'

import { useMemo } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { useState } from 'react'

const generateHeatmapData = () => {
  const hours = Array.from({ length: 12 }, (_, i) => i + 9) // 9 AM to 8 PM
  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
  
  return days.map(day => ({
    day,
    hours: hours.map(hour => ({
      hour,
      value: Math.floor(Math.random() * 100) + (day === 'Sat' || day === 'Sun' ? 30 : 0) + (hour >= 12 && hour <= 14 ? 20 : 0)
    }))
  }))
}

const getHeatColor = (value: number, max: number) => {
  const ratio = value / max
  if (ratio < 0.25) return 'bg-blue-900/40'
  if (ratio < 0.5) return 'bg-blue-600/60'
  if (ratio < 0.75) return 'bg-primary/70'
  return 'bg-primary'
}

export function TrafficHeatmap() {
  const [timeRange, setTimeRange] = useState('week')
  const data = useMemo(() => generateHeatmapData(), [])
  const maxValue = useMemo(() => 
    Math.max(...data.flatMap(d => d.hours.map(h => h.value))),
    [data]
  )
  const hours = Array.from({ length: 12 }, (_, i) => i + 9)

  return (
    <Card className="border-border bg-card">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <div>
          <CardTitle className="text-base font-medium">Traffic Heatmap</CardTitle>
          <CardDescription className="text-muted-foreground">
            Customer visits by hour
          </CardDescription>
        </div>
        <Select value={timeRange} onValueChange={setTimeRange}>
          <SelectTrigger className="w-28 h-8 text-xs">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="week">This Week</SelectItem>
            <SelectItem value="month">This Month</SelectItem>
            <SelectItem value="quarter">Quarter</SelectItem>
          </SelectContent>
        </Select>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <div className="min-w-[500px]">
            <div className="mb-2 flex gap-1 pl-10">
              {hours.map(hour => (
                <div key={hour} className="flex-1 text-center text-[10px] text-muted-foreground">
                  {hour > 12 ? `${hour - 12}p` : hour === 12 ? '12p' : `${hour}a`}
                </div>
              ))}
            </div>
            <div className="space-y-1">
              {data.map(({ day, hours: hourData }) => (
                <div key={day} className="flex items-center gap-1">
                  <div className="w-8 text-xs text-muted-foreground">{day}</div>
                  <div className="flex flex-1 gap-1">
                    {hourData.map(({ hour, value }) => (
                      <div
                        key={hour}
                        className={`flex-1 h-6 rounded-sm transition-colors cursor-pointer hover:ring-1 hover:ring-primary/50 ${getHeatColor(value, maxValue)}`}
                        title={`${day} ${hour > 12 ? hour - 12 : hour}:00 ${hour >= 12 ? 'PM' : 'AM'} - ${value} visitors`}
                      />
                    ))}
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-4 flex items-center justify-center gap-2">
              <span className="text-xs text-muted-foreground">Low</span>
              <div className="flex gap-1">
                <div className="h-3 w-6 rounded-sm bg-blue-900/40" />
                <div className="h-3 w-6 rounded-sm bg-blue-600/60" />
                <div className="h-3 w-6 rounded-sm bg-primary/70" />
                <div className="h-3 w-6 rounded-sm bg-primary" />
              </div>
              <span className="text-xs text-muted-foreground">High</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
