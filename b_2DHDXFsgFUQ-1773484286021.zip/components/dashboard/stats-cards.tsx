'use client'

import { Card, CardContent } from '@/components/ui/card'
import { ArrowDownRight, ArrowUpRight, Users, ShoppingCart, Clock, TrendingUp } from 'lucide-react'
import { cn } from '@/lib/utils'

const stats = [
  {
    title: 'Total Visitors',
    value: '12,847',
    change: '+14.2%',
    trend: 'up' as const,
    icon: Users,
    description: 'vs last week'
  },
  {
    title: 'Conversion Rate',
    value: '24.8%',
    change: '+3.1%',
    trend: 'up' as const,
    icon: ShoppingCart,
    description: 'vs last week'
  },
  {
    title: 'Avg. Dwell Time',
    value: '18m 32s',
    change: '-2.4%',
    trend: 'down' as const,
    icon: Clock,
    description: 'vs last week'
  },
  {
    title: 'Revenue/Visitor',
    value: '$47.20',
    change: '+8.7%',
    trend: 'up' as const,
    icon: TrendingUp,
    description: 'vs last week'
  }
]

export function StatsCards() {
  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
      {stats.map((stat) => {
        const Icon = stat.icon
        return (
          <Card key={stat.title} className="border-border bg-card">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                  <Icon className="h-5 w-5 text-primary" />
                </div>
                <div className={cn(
                  'flex items-center gap-0.5 text-xs font-medium',
                  stat.trend === 'up' ? 'text-green-400' : 'text-red-400'
                )}>
                  {stat.trend === 'up' ? (
                    <ArrowUpRight className="h-3 w-3" />
                  ) : (
                    <ArrowDownRight className="h-3 w-3" />
                  )}
                  {stat.change}
                </div>
              </div>
              <div className="mt-4">
                <p className="text-2xl font-semibold text-foreground">{stat.value}</p>
                <p className="text-sm text-muted-foreground">{stat.title}</p>
              </div>
              <p className="mt-1 text-xs text-muted-foreground/70">{stat.description}</p>
            </CardContent>
          </Card>
        )
      })}
    </div>
  )
}
