'use client'

import { useMemo } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { ChartContainer, ChartTooltip, ChartTooltipContent } from '@/components/ui/chart'
import { AreaChart, Area, XAxis, YAxis, ResponsiveContainer, CartesianGrid } from 'recharts'

const generateTrafficData = () => {
  const hours = Array.from({ length: 24 }, (_, i) => {
    const hour = i
    const isBusinessHours = hour >= 9 && hour <= 20
    const isPeakHours = (hour >= 11 && hour <= 14) || (hour >= 17 && hour <= 19)
    
    let baseTraffic = isBusinessHours ? 50 + Math.random() * 30 : 5 + Math.random() * 10
    if (isPeakHours) baseTraffic += 40 + Math.random() * 30
    
    return {
      hour: `${hour.toString().padStart(2, '0')}:00`,
      visitors: Math.round(baseTraffic),
      conversions: Math.round(baseTraffic * (0.15 + Math.random() * 0.15))
    }
  })
  return hours
}

export function TrafficChart() {
  const data = useMemo(() => generateTrafficData(), [])
  
  // Compute colors in JS for Recharts
  const primaryColor = '#7c6aef'
  const secondaryColor = '#4ecdc4'

  return (
    <Card className="border-border bg-card">
      <CardHeader className="pb-2">
        <CardTitle className="text-base font-medium">Today{"'"}s Traffic</CardTitle>
        <CardDescription className="text-muted-foreground">
          Visitors and conversions by hour
        </CardDescription>
      </CardHeader>
      <CardContent>
        <ChartContainer
          config={{
            visitors: {
              label: 'Visitors',
              color: primaryColor,
            },
            conversions: {
              label: 'Conversions',
              color: secondaryColor,
            },
          }}
          className="h-[200px] w-full"
        >
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={data} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="visitorsGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={primaryColor} stopOpacity={0.3} />
                  <stop offset="95%" stopColor={primaryColor} stopOpacity={0} />
                </linearGradient>
                <linearGradient id="conversionsGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={secondaryColor} stopOpacity={0.3} />
                  <stop offset="95%" stopColor={secondaryColor} stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
              <XAxis 
                dataKey="hour" 
                tick={{ fontSize: 10, fill: 'rgba(255,255,255,0.5)' }}
                tickLine={false}
                axisLine={false}
                interval={3}
              />
              <YAxis 
                tick={{ fontSize: 10, fill: 'rgba(255,255,255,0.5)' }}
                tickLine={false}
                axisLine={false}
              />
              <ChartTooltip content={<ChartTooltipContent />} />
              <Area
                type="monotone"
                dataKey="visitors"
                stroke={primaryColor}
                strokeWidth={2}
                fill="url(#visitorsGradient)"
              />
              <Area
                type="monotone"
                dataKey="conversions"
                stroke={secondaryColor}
                strokeWidth={2}
                fill="url(#conversionsGradient)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </ChartContainer>
        <div className="mt-2 flex items-center justify-center gap-6">
          <div className="flex items-center gap-2">
            <div className="h-2 w-2 rounded-full" style={{ backgroundColor: primaryColor }} />
            <span className="text-xs text-muted-foreground">Visitors</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="h-2 w-2 rounded-full" style={{ backgroundColor: secondaryColor }} />
            <span className="text-xs text-muted-foreground">Conversions</span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
