'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'
import { 
  Sparkles, 
  TrendingUp, 
  Users, 
  ShoppingBag, 
  ArrowRight,
  Check,
  Clock,
  Lightbulb,
  Target,
  Zap
} from 'lucide-react'

interface Recommendation {
  id: string
  title: string
  description: string
  impact: 'high' | 'medium' | 'low'
  category: 'layout' | 'staffing' | 'inventory' | 'marketing'
  metric: string
  metricValue: string
  icon: React.ReactNode
  status: 'new' | 'applied' | 'dismissed'
}

const initialRecommendations: Recommendation[] = [
  {
    id: '1',
    title: 'Relocate Beauty Section',
    description: 'Move beauty products closer to entrance to capture early foot traffic. Data shows 73% of beauty buyers enter from main entrance.',
    impact: 'high',
    category: 'layout',
    metric: 'Projected Revenue',
    metricValue: '+12%',
    icon: <Target className="h-4 w-4" />,
    status: 'new'
  },
  {
    id: '2',
    title: 'Peak Hour Staffing',
    description: 'Add 2 staff members to checkout between 12-2 PM. Average wait time is 8 minutes during this period.',
    impact: 'high',
    category: 'staffing',
    metric: 'Wait Time Reduction',
    metricValue: '-45%',
    icon: <Users className="h-4 w-4" />,
    status: 'new'
  },
  {
    id: '3',
    title: 'Cross-sell Electronics',
    description: 'Place phone accessories near electronics exit. 68% of phone buyers also view accessories but only 12% purchase.',
    impact: 'medium',
    category: 'inventory',
    metric: 'Attachment Rate',
    metricValue: '+28%',
    icon: <ShoppingBag className="h-4 w-4" />,
    status: 'new'
  },
  {
    id: '4',
    title: 'Weekend Promotions',
    description: 'Deploy targeted promotions on Saturday afternoons when traffic is 40% higher but conversion is below average.',
    impact: 'medium',
    category: 'marketing',
    metric: 'Conversion Rate',
    metricValue: '+18%',
    icon: <Zap className="h-4 w-4" />,
    status: 'applied'
  },
  {
    id: '5',
    title: 'Optimize Cafe Flow',
    description: 'Reconfigure seating to improve traffic flow. Current layout creates bottleneck during peak hours.',
    impact: 'low',
    category: 'layout',
    metric: 'Dwell Time',
    metricValue: '+22%',
    icon: <Lightbulb className="h-4 w-4" />,
    status: 'new'
  }
]

export function AIRecommendations() {
  const [recommendations, setRecommendations] = useState<Recommendation[]>(initialRecommendations)
  const [filter, setFilter] = useState<'all' | 'new' | 'applied'>('all')

  const handleApply = (id: string) => {
    setRecommendations(prev => 
      prev.map(r => r.id === id ? { ...r, status: 'applied' as const } : r)
    )
  }

  const handleDismiss = (id: string) => {
    setRecommendations(prev => 
      prev.map(r => r.id === id ? { ...r, status: 'dismissed' as const } : r)
    )
  }

  const filteredRecommendations = recommendations.filter(r => {
    if (filter === 'all') return r.status !== 'dismissed'
    return r.status === filter
  })

  const getImpactColor = (impact: 'high' | 'medium' | 'low') => {
    switch (impact) {
      case 'high': return 'bg-green-500/20 text-green-400 border-green-500/30'
      case 'medium': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30'
      case 'low': return 'bg-blue-500/20 text-blue-400 border-blue-500/30'
    }
  }

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'layout': return 'text-primary'
      case 'staffing': return 'text-cyan-400'
      case 'inventory': return 'text-orange-400'
      case 'marketing': return 'text-pink-400'
      default: return 'text-muted-foreground'
    }
  }

  return (
    <Card className="border-border bg-card h-full">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/20">
              <Sparkles className="h-4 w-4 text-primary" />
            </div>
            <div>
              <CardTitle className="text-base font-medium">AI Insights</CardTitle>
              <CardDescription className="text-xs text-muted-foreground">
                Powered by traffic analysis
              </CardDescription>
            </div>
          </div>
          <Badge variant="outline" className="text-xs gap-1">
            <TrendingUp className="h-3 w-3" />
            {recommendations.filter(r => r.status === 'new').length} new
          </Badge>
        </div>
        <div className="flex gap-1 pt-2">
          {(['all', 'new', 'applied'] as const).map(f => (
            <Button
              key={f}
              variant={filter === f ? 'secondary' : 'ghost'}
              size="sm"
              className="h-7 text-xs capitalize"
              onClick={() => setFilter(f)}
            >
              {f}
            </Button>
          ))}
        </div>
      </CardHeader>
      <CardContent className="space-y-3 max-h-[520px] overflow-y-auto">
        {filteredRecommendations.map(rec => (
          <div
            key={rec.id}
            className={cn(
              'group rounded-lg border p-3 transition-all',
              rec.status === 'applied' 
                ? 'border-green-500/30 bg-green-500/5' 
                : 'border-border bg-secondary/30 hover:border-primary/30 hover:bg-secondary/50'
            )}
          >
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-center gap-2">
                <span className={getCategoryColor(rec.category)}>{rec.icon}</span>
                <span className="text-sm font-medium text-foreground">{rec.title}</span>
              </div>
              <Badge 
                variant="outline" 
                className={cn('text-[10px] capitalize', getImpactColor(rec.impact))}
              >
                {rec.impact}
              </Badge>
            </div>
            
            <p className="mt-2 text-xs text-muted-foreground leading-relaxed">
              {rec.description}
            </p>

            <div className="mt-3 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-[10px] text-muted-foreground">{rec.metric}</span>
                <span className="text-sm font-semibold text-green-400">{rec.metricValue}</span>
              </div>
              
              {rec.status === 'new' ? (
                <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <Button 
                    size="sm" 
                    variant="ghost" 
                    className="h-6 text-xs px-2 text-muted-foreground hover:text-foreground"
                    onClick={() => handleDismiss(rec.id)}
                  >
                    Dismiss
                  </Button>
                  <Button 
                    size="sm" 
                    className="h-6 text-xs px-2 gap-1"
                    onClick={() => handleApply(rec.id)}
                  >
                    Apply <ArrowRight className="h-3 w-3" />
                  </Button>
                </div>
              ) : rec.status === 'applied' ? (
                <div className="flex items-center gap-1 text-green-400">
                  <Check className="h-3 w-3" />
                  <span className="text-xs">Applied</span>
                </div>
              ) : null}
            </div>
          </div>
        ))}

        {filteredRecommendations.length === 0 && (
          <div className="flex flex-col items-center justify-center py-8 text-center">
            <Clock className="h-8 w-8 text-muted-foreground/50 mb-2" />
            <p className="text-sm text-muted-foreground">No recommendations</p>
            <p className="text-xs text-muted-foreground/70">Check back later for new insights</p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
